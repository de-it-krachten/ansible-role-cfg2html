# @(#) $Id: README.txt,v 6.11 2013-09-12 19:07:12 ralph Exp $
# -------------------------------------------------------------------------
# vim:ts=8:sw=4:sts=4 


This directory will contain source code for programs to compile (mostly C stuff).

I suggest to use sub directories:

 plugins - source code for plugins (currently hpux stuff)
 tools - source code for helper tools (e.g. mywhat.c for build process)

Ralph - 12.09.2013

